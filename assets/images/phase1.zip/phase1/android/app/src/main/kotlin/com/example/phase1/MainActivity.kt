package com.example.phase1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
