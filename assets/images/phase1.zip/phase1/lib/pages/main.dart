import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:phase1/pages/welcome.dart';
import 'cardetails.dart';
import 'home.dart';
import 'faqs.dart';
import 'settings.dart';
import 'profile.dart';
import 'login.dart';
import 'loginmain.dart';
import 'splash_screen.dart';
import 'LoginSignup.dart';
import 'signup.dart';
import 'addcar.dart';
import 'welcome.dart';
import 'navbar.dart';
import 'availablecar_screen.dart';



void main() {

  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final page = [home(),profile(),faqs(),SettingPage()];
   int currentpage=0;
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
         body: SplashScreen(),
      ),
    );
  }
}
