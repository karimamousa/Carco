import 'package:flutter/material.dart';
import 'welcome.dart';
class profile extends StatefulWidget {
  const profile({super.key});

  @override
  State<profile> createState() => _profileState();
}

class _profileState extends State<profile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          leading: IconButton(icon: Icon(Icons.arrow_back) ,
            color: Colors.white,
            onPressed: () => {
              Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context)=>welcome()),(route)=>false)},
          ),
        backgroundColor: Color(0xff00637c),
    automaticallyImplyLeading: false,

    elevation: 0,
    centerTitle: true,
    title: Text('Profile',
    style: TextStyle(
    color: Colors.white,
    fontSize: 30.0
    ))
    ),

    );
  }
}
