
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'home.dart';
import 'welcome.dart';
import 'navbar.dart';

class AddCar extends StatefulWidget {
  const AddCar({Key? key}) : super(key: key);

  @override
  _AddCarState createState() => _AddCarState();
}

class _AddCarState extends State
{

  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      // This call to setState tells the Flutter framework that something has
      // changed in this State, which causes it to rerun the build method below
      // so that the display can reflect the updated values. If we changed
      // _counter without calling setState(), then the build method would not be
      // called again, and so nothing would appear to happen.
      _counter++;
    });}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff00637c),
        automaticallyImplyLeading: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          color: Colors.white,
          onPressed: () => {
            Navigator.of(context).push(MaterialPageRoute(builder: (context)=>welcome()))
          },
        ),
      ),
      body: Stack(
        children: [
          Container(
            height: double.infinity,
            width: double.infinity,
            decoration: const BoxDecoration(
              color: Color(0xff00637c),
            ),
            child: const Padding(
              padding: EdgeInsets.only(top: 60.0, left: 22),
              child: Text(
                'ADD YOUR CAR \n FOR RENT',
                style: TextStyle(
                  fontSize: 30,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 200.0),
            child: Container(
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(40),
                  topRight: Radius.circular(40),
                ),
                color: Colors.white,
              ),
              height: double.infinity,
              width: double.infinity,
              child: Padding(
                padding: const EdgeInsets.only(left: 18.0, right: 18),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextField(
                      decoration: InputDecoration(
                        suffixIcon: Icon(Icons.person, color: Colors.grey,),
                        label: Text(
                          'Full Name',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xff00637c),
                          ),
                        ),
                      ),
                    ),
                    TextField(
                      decoration: InputDecoration(
                        suffixIcon: Icon(Icons.phone, color: Colors.grey,),
                        label: Text(
                          'Whatsapp Number',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xff00637c),
                          ),
                        ),
                      ),
                    ),
                    TextField(
                      decoration: InputDecoration(
                        suffixIcon: Icon(Icons.location_city, color: Colors.grey,),
                        label: Text(
                          'Address',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xff00637c),
                          ),
                        ),
                      ),
                    ),
                    TextField(
                      decoration: InputDecoration(
                        suffixIcon: Icon(Icons.email, color: Colors.grey,),
                        label: Text(
                          'Email',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xff00637c),
                          ),
                        ),
                      ),
                    ),
                    TextField(
                      decoration: InputDecoration(
                        suffixIcon: Icon(Icons.details, color: Colors.grey,),
                        label: Text(
                          'About Your Car',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xff00637c),
                          ),
                        ),
                      ),
                    ),
                    TextField(
                      decoration: InputDecoration(
                        suffixIcon: Icon(Icons.numbers, color: Colors.grey,),
                        label: Text(
                          'Car License',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xff00637c),
                          ),
                        ),
                      ),
                    ),
                    TextField(
                      decoration: InputDecoration(
                        suffixIcon: Icon(Icons.calendar_today_rounded, color: Colors.grey,),
                        label: Text(
                          'Available Days to list your car for rent',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xff00637c),
                          ),
                        ),
                      ),
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            decoration: InputDecoration(
                              //suffixIcon: Icon(Icons.car_rental, color: Colors.grey,),
                              label: Text(
                                'Price',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xff00637c),
                                ),
                              ),
                              // Set the text to the counter value
                              //controller: TextEditingController(text: '\$$counter'),
                            ),
                          ),
                        ),
                        IconButton(
                            icon: Icon(Icons.add),
                            onPressed: _incrementCounter
                        ),
                        IconButton(
                            icon: Icon(Icons.remove),
                            onPressed: _incrementCounter
                        ),
                        Text(
                          '$_counter',
                          style: Theme.of(context).textTheme.headlineMedium,
                        ),
                      ],
                    ),
                    SizedBox(height: 50,),
                    Container(
                      height: 55,
                      width: 300,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        color: Color(0xff00637c),
                      ),
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).push(MaterialPageRoute(builder: (context)=>navbar()));
                        },
                        style: ElevatedButton.styleFrom(
                          surfaceTintColor: Color(0xff00637c),
                          backgroundColor: Color(0xff00637c),
                          side: BorderSide(color: Color(0xff00637c)),
                          elevation: 20,
                          minimumSize: const Size.fromHeight(60),
                        ),
                        child: Text("SUBMIT", style:TextStyle(color:Colors.white,)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
